AMORAL — сайт со ссылками

Файлы:
- index.html — весь сайт (HTML, CSS и JavaScript в одном файле).

Уже добавлены:
- TikTok: https://www.tiktok.com/@amoral907
- Telegram: https://t.me/holodezfn

Что нужно заменить:
1. Открой index.html в редакторе (например, Блокнот).
2. Найди href="#" у карточек Telegram Stories / Travel и Discord.
3. Замени # на полную ссылку, например https://t.me/your_channel или https://discord.gg/yourinvite.
4. Сохрани файл.

Бесплатная публикация через GitHub Pages:
1. Войди или зарегистрируйся на github.com.
2. Создай новый публичный репозиторий, например amoral-links.
3. Загрузи index.html в корень репозитория (Add file → Upload files → Commit changes).
4. Открой Settings → Pages.
5. В разделе Build and deployment выбери Deploy from a branch, ветку main и папку /(root), нажми Save.
6. Через несколько минут сайт появится по адресу вида https://ТВОЙ-ЛОГИН.github.io/amoral-links/

Альтернатива: Netlify Drop — можно перетащить папку сайта на https://app.netlify.com/drop. Сервис может попросить войти в аккаунт.

Перед публикацией обязательно проверь, что ссылки ведут на твои официальные аккаунты.
